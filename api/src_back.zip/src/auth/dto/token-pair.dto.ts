export class TokenPairDto {
    accessToken: string;
    refreshToken: string;
  }